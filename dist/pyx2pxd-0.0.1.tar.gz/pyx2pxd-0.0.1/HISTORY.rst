=======
History
=======

0.0.1 (2023-01-17)
------------------

* First release on PyPI.
