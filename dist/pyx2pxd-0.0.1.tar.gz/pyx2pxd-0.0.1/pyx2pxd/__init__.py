"""Top-level package for pyx2pxd."""

__author__ = """Bruno Manuel Santos Saraiva"""
__email__ = 'bruno.msaraiva2@gmail.com'
__version__ = '0.0.1'
