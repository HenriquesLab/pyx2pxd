=====
Usage
=====

To use pyx2pxd in a project::

    import pyx2pxd
