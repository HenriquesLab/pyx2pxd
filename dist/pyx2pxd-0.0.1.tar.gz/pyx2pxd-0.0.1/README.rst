=======
pyx2pxd
=======


.. image:: https://img.shields.io/pypi/v/pyx2pxd.svg
        :target: https://pypi.python.org/pypi/pyx2pxd

.. image:: https://img.shields.io/travis/brunomsaraiva/pyx2pxd.svg
        :target: https://travis-ci.com/brunomsaraiva/pyx2pxd

.. image:: https://readthedocs.org/projects/pyx2pxd/badge/?version=latest
        :target: https://pyx2pxd.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/brunomsaraiva/pyx2pxd/shield.svg
     :target: https://pyup.io/repos/github/brunomsaraiva/pyx2pxd/
     :alt: Updates



Automatically generates pxd files form pyx files


* Free software: MIT license
* Documentation: https://pyx2pxd.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
